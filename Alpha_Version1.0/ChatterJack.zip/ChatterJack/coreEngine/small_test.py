import pymysql

from segmentation import Segment
from coredata import table_list

try:
    db = pymysql.connect(host='localhost',
                         port=3306,
                         user='root',
                         password='111',
                         database='chatterjack',
                         charset='utf8',
                         cursorclass=pymysql.cursors.DictCursor)
except pymysql.Error as e:
    print('Database connect fail')

grab = Segment()
questions = input('Questions: ')
searchInf = grab.intention(questions)
print(searchInf)
tables = []
table = 'ORG'
for value in searchInf.values():
    if value in table_list:
        tables.append(value)
for key, value in searchInf.items():
    if value == 'PERSON':
        name = key
    if value == 'INTER':
        inter = key
    if value == 'ORG':
        organName = key

if 'PERSON' in tables:
    searching = "SELECT " + inter + " FROM " + table + " WHERE `person_name` LIKE %s;"
    with db.cursor() as cursor:
        cursor.execute(searching, ('%'+name+'%'))
        answers = cursor.fetchone()
        for value in answers.values():
            answer = value
        print(answer)

if table == 'ORG':
    searching = "SELECT " + inter + " FROM " + table + " WHERE `org_name` LIKE %s;"
    try:
        with db.cursor() as cursor:
            cursor.execute(searching, [('%' + organName + '%')])
            answers = cursor.fetchone()
            for value in answers.values():
                answer = value
            print(answer)
    except pymysql.Error as e:
        print('Error')