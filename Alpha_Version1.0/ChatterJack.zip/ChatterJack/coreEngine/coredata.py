"""
 These are all the core data used in different files.
"""

interrogatives = ['what', 'where', 'when', 'how', 'which', 'who']

nauInf = ['siccs', 'ceias', 'nau', 'sbs', 'engineering building', 'cline library', 'engineering']

calls = ['dr', 'ms', 'mr', 'miss', 'mrs', 'dr.', 'ms.', 'mr.', 'miss.']

table_list = ['ORG', 'PERSON', 'CLASS']

# ending the conversation
stop = ['no']
# continuing the conversation
still = ['yes', 'yeah', 'course', 'yep']
# start the conversation
startMess = "Hello, My name is ChatterJack chatbot. You can ask me the information of professors, the location, and anything you want to know about NAU."
# asking if there any questions?
nextMess = "Do you have any other questions?"
# continuing message after typing yes
stillMess = "What else do you want to know?"
# ending the conversation
endMess = "Thanks for asking. Hopefully, the answer will help you. Have a nice day!"
